package com.example.lifecycledemo;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import java.util.ArrayList;
import java.util.List;

public class SecondActivity extends AppCompatActivity {

    private TextView textViewBalance;
    private EditText editTextRecipient;
    private EditText editname;
    private SeekBar seekBarAmount;
    private TextView textViewAmount;
    private Button buttonSend;
    private TextView textViewHistory;
    private ImageView imageViewLogo;

    private double balance = 1000.0;
    private List<String> transactionHistory = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second); // Use the correct layout file

        // Initialize views
        textViewBalance = findViewById(R.id.textViewBalance);
        editTextRecipient = findViewById(R.id.editTextRecipient);
        editname = findViewById(R.id.editNumer); // Initialize editname
        seekBarAmount = findViewById(R.id.seekBarAmount);
        textViewAmount = findViewById(R.id.textViewAmount);
        buttonSend = findViewById(R.id.buttonSend);
        textViewHistory = findViewById(R.id.textViewHistory);
        imageViewLogo = findViewById(R.id.imageViewLogo);

        // Set initial balance
        updateBalance();

        // Set SeekBar listener
        seekBarAmount.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                textViewAmount.setText("Amount: $" + progress);
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
                // Not needed
            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                // Not needed
            }
        });

        // Set button click listener
        buttonSend.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sendMoney();
            }
        });
    }

    private void sendMoney() {
        String recipient = editTextRecipient.getText().toString().trim();
        String name = editname.getText().toString().trim(); // Get name from editname
        int amount = seekBarAmount.getProgress();

        // Validate input
        if (recipient.isEmpty()) {
            Toast.makeText(this, "Please enter recipient name", Toast.LENGTH_SHORT).show();
            return;
        }

        if (name.isEmpty()) { // Validate name field
            Toast.makeText(this, "Please enter your name", Toast.LENGTH_SHORT).show();
            return;
        }

        if (amount == 0) {
            Toast.makeText(this, "Please select an amount", Toast.LENGTH_SHORT).show();
            return;
        }

        if (amount > balance) {
            Toast.makeText(this, "Insufficient balance", Toast.LENGTH_SHORT).show();
            return;
        }

        // Update balance and transaction history
        balance -= amount;
        updateBalance();

        String transaction = name + " sent $" + amount + " to " + recipient; // Include name in transaction
        transactionHistory.add(transaction);
        updateTransactionHistory();

        // Clear input fields
        editTextRecipient.setText("");
        editname.setText(""); // Clear name field
        seekBarAmount.setProgress(0);

        Toast.makeText(this, "Money sent successfully", Toast.LENGTH_SHORT).show();
    }

    private void updateBalance() {
        textViewBalance.setText("Balance: $" + balance);
    }

    private void updateTransactionHistory() {
        StringBuilder history = new StringBuilder("Transaction History:\n");
        for (String transaction : transactionHistory) {
            history.append(transaction).append("\n");
        }
        textViewHistory.setText(history.toString());
    }
}